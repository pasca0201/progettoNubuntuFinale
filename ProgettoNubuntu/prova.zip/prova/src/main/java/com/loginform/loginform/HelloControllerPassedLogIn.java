package com.loginform.loginform;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import org.w3c.dom.events.MouseEvent;

import java.io.IOException;

public class HelloControllerPassedLogIn {

    @FXML
    private Button gestioneFontiButton;
    @FXML
    private Button cancelButton;
    @FXML
    private Button rimuoviNotizieButton;
    @FXML
    private Button rimuoviCommentiButton;


    @FXML
    protected void cancelButton(MouseEvent event) {
        Stage stage = (Stage) cancelButton.getScene().getWindow();
        stage.close();
    }


    @FXML
    protected void gestioneFontiButton(MouseEvent event){

                    FXMLLoader fxmlLoader3 = new FXMLLoader();
                    fxmlLoader3.setLocation(getClass().getResource("paginaGestioneFonti.fxml"));
                    Scene scene2;
                    try {
                        scene2 = new Scene(fxmlLoader3.load(), 600, 400);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                    Stage stage2 = new Stage();
                    stage2.setTitle("Gestione Fonti");
                    stage2.setScene(scene2);
                    stage2.show();


    }

    @FXML
    protected void rimuoviNotizieButton(MouseEvent event){

                    FXMLLoader fxmlLoader4 = new FXMLLoader();
                    fxmlLoader4.setLocation(getClass().getResource("paginaRImozioneNotizie.fxml"));


                    Scene scene3;
                    try {
                        scene3 = new Scene(fxmlLoader4.load(), 600, 400);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                    Stage stage3 = new Stage();
                    stage3.setTitle("Gestione Notizie");
                    stage3.setScene(scene3);
                    stage3.show();
        
    }

    @FXML
    protected void rimuoviCommentiButton(MouseEvent event){

                    FXMLLoader fxmlLoader5 = new FXMLLoader();
                    fxmlLoader5.setLocation(getClass().getResource("paginaRimozioneCommenti.fxml"));


                    Scene scene4;
                    try {
                        scene4 = new Scene(fxmlLoader5.load(), 600, 400);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                    Stage stage4 = new Stage();
                    stage4.setTitle("Gestione Notizie");
                    stage4.setScene(scene4);
                    stage4.show();

    }


}
