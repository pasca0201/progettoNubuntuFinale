package com.loginform.loginform;

import TelegramBot.GestioneCommenti;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import org.w3c.dom.events.MouseEvent;

import java.net.URL;
import java.util.ResourceBundle;

public class ControlloCommenti implements Initializable {

    GestioneCommenti g = new GestioneCommenti();

    @FXML
    private ListView<String> commentsBox;

    @FXML
    private Button deleteComment;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        commentsBox.getItems().addAll(g.getCommenti().toString());
    }

    @FXML
    public void deleteComment(MouseEvent event){
        String selectedID = commentsBox.getSelectionModel().getSelectedItem();
        commentsBox.getItems().remove(selectedID);
        String [] tokens =selectedID.split(" ");
        g.rimuoviCommento(tokens[0], tokens[1]);

    }
}
