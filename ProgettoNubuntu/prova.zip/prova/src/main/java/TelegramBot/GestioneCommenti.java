package TelegramBot;

import java.io.*;
import java.util.HashMap;
import java.util.Scanner;

public class GestioneCommenti {

    private HashMap<String,String> commenti;//titolo commento

    public GestioneCommenti(){
        commenti=new HashMap<String,String>();
        Scanner scan=null;
        try{
            scan=new Scanner(new File("commenti.txt"));
            scan.nextLine();
            //prima riga sarà sempre da inserire
            String[] tokens = scan.nextLine().split("#");
            String tit = tokens[1];
            String comm = tokens[3];
            commenti.put(tit, comm);

            while(scan.hasNextLine()){

                String riga=scan.nextLine();

                if(riga.substring(0,14).equals("titolo notizia")) {

                    tokens = riga.split("#");
                    tit = tokens[1];
                    comm = tokens[3];
                    String commPrec="";

                    if(commenti.containsKey(tokens[1])){
                        //valori associati titolo
                        commPrec=commenti.get(tokens[1]);
                        System.out.println(commPrec);
                        comm=comm+" "+commPrec;
                        commenti.put(tit, comm);
                    }else{
                        commenti.put(tit, comm);
                    }
                }
            }

        }catch(FileNotFoundException e){
            e.printStackTrace();
        }
        scan.close();
    }

    public void aggiungiCommento(String titolo,String commento) {
        commenti.put(titolo, commento);
        PrintWriter p = null;
        try {
            FileWriter f = new FileWriter("commenti.txt", true);
            p = new PrintWriter(f);
            p.println("titolo notizia# " + titolo + "# commento# " + commento);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        p.close();
    }

    public void rimuoviCommento(String titolo,String commento){
        commenti.remove(titolo,commento);
        PrintWriter p = null;
        try {
            FileWriter f = new FileWriter("commenti.txt", true);
            p = new PrintWriter(f);
            p.println("- "+"titolo notizia# " + titolo + "# commento# " + commento);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        p.close();
    }


    public void toString(HashMap<String, String> map){
        for (String key: map.keySet()){
            System.out.println(key+ " = " + map.get(key));
        }
    }

    public HashMap<String, String> getCommenti() {
        return commenti;
    }

    public void setCommenti(HashMap<String, String> commenti) {
        this.commenti = commenti;
    }
}