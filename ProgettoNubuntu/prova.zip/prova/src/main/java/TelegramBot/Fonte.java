package TelegramBot;

public class Fonte {
    private String link;

    public Fonte() {
        this.link = null;
    }

    public Fonte(String link) {
        this.link = link;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }
}
