package TelegramBot;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.TreeMap;

public class Categorie {

    ArrayList<String> categories;


    public Categorie(){
        categories=new ArrayList<String>();
        try
        {

            GsonBuilder builder = new GsonBuilder();
            builder.setPrettyPrinting();

            Gson gson = builder.create();
            BufferedReader bufferedReader = new BufferedReader(
                    new FileReader("categorie.json"));
            categories = gson.fromJson(bufferedReader, ArrayList.class);
            System.out.println("output di debug: ecco come è arraylist");
            System.out.println(categories);

        } catch(FileNotFoundException e)
        {
            categories=new ArrayList<String>();
            System.out.println("non ha trovato il file");
        }
    }

    public ArrayList<String> getCategories() {
        return categories;
    }

    public void setCategories(ArrayList<String> categories) {
        this.categories = categories;
    }

    public static void main(String[] args){
        ArrayList<String> categories=new ArrayList<String>();
        try
        {

            GsonBuilder builder = new GsonBuilder();
            builder.setPrettyPrinting();

            Gson gson = builder.create();
            BufferedReader bufferedReader = new BufferedReader(
                    new FileReader("categorie.json"));
            categories = gson.fromJson(bufferedReader, ArrayList.class);
            System.out.println("output di debug: ecco come è arraylist");
            System.out.println(categories);

        } catch(FileNotFoundException e)
        {
            categories=new ArrayList<String>();
            System.out.println("non ha trovato il file");
        }
    }
}
